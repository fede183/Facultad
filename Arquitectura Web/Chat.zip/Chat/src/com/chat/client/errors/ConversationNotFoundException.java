package com.chat.client.errors;

import java.io.Serializable;

public class ConversationNotFoundException extends Exception implements Serializable {

}
