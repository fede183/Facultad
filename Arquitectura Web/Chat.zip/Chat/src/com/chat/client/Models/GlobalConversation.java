package com.chat.client.Models;

import com.google.gwt.user.client.rpc.IsSerializable;

public class GlobalConversation extends Conversation implements IsSerializable {
    public GlobalConversation() {
    }
}
