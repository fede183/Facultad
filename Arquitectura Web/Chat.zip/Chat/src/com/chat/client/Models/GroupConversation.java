package com.chat.client.Models;

public class GroupConversation extends Conversation{

    public GroupConversation() {
    }

    public void addMessage(Message message){
        super.addMessage(message);
    }
}
