/*******************************************************************************
 * This file is part of the AbcDatalog project.
 *
 * Copyright (c) 2016, Harvard University
 * All rights reserved.
 *
 * This program and the accompanying materials are made available under
 * the terms of the BSD License which accompanies this distribution.
 *
 * The development of the AbcDatalog project has been supported by the 
 * National Science Foundation under Grant Nos. 1237235 and 1054172.
 *
 * See README for contributors.
 ******************************************************************************/
/**
 * This packages contains classes representing the core abstract syntax tree for
 * AbcDatalog. Many of these classes support the visitor design pattern; see
 * {@link abcdatalog.ast.visitors}.
 */
package abcdatalog.ast;