# This file is part of the ORBS distribution.
# See the file LICENSE.TXT for more information.

This is an example for ORBS based on the example given in the report
on ORBS.
