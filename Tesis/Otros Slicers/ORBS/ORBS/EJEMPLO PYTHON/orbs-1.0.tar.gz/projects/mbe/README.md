# This file is part of the ORBS distribution.
# See the file LICENSE.TXT for more information.

This is the "Montreal Boat Example" for ORBS.
